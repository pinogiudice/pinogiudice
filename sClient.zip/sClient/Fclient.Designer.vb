﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FClient
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla mediante l'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FClient))
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.cMenuS = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.TSchiudi = New System.Windows.Forms.ToolStripMenuItem()
        Me.cMenuS.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer1
        '
        Me.Timer1.Interval = 3000
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.ContextMenuStrip = Me.cMenuS
        Me.NotifyIcon1.Icon = CType(resources.GetObject("NotifyIcon1.Icon"), System.Drawing.Icon)
        Me.NotifyIcon1.Text = "sClient"
        Me.NotifyIcon1.Visible = True
        '
        'cMenuS
        '
        Me.cMenuS.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TSchiudi})
        Me.cMenuS.Name = "cMenuS"
        Me.cMenuS.Size = New System.Drawing.Size(181, 48)
        '
        'TSchiudi
        '
        Me.TSchiudi.Name = "TSchiudi"
        Me.TSchiudi.Size = New System.Drawing.Size(180, 22)
        Me.TSchiudi.Text = "Chiudi"
        '
        'FClient
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(222, 97)
        Me.ControlBox = False
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FClient"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.Text = "Client"
        Me.WindowState = System.Windows.Forms.FormWindowState.Minimized
        Me.cMenuS.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Timer1 As Timer
    Friend WithEvents NotifyIcon1 As NotifyIcon
    Friend WithEvents cMenuS As ContextMenuStrip
    Friend WithEvents TSchiudi As ToolStripMenuItem
End Class
