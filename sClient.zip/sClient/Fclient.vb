﻿Imports System.Net.Sockets
Imports System.Text

Public Class FClient

    Dim clientSocket As New System.Net.Sockets.TcpClient()

    Dim serverStream As NetworkStream
    Dim uname, client As String

    Function GetMyIP() As String
        Dim AllNetInterfaces = System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces()
        For Each NetworkInterface In AllNetInterfaces
            Dim props = NetworkInterface.GetIPProperties
            For Each address In props.UnicastAddresses
                If address.Address.AddressFamily = Net.Sockets.AddressFamily.InterNetwork Then
                    If NetworkInterface.OperationalStatus = System.Net.NetworkInformation.OperationalStatus.Up Then


                        Return (address.Address.ToString)
                    End If
                End If
            Next
        Next
        Return ""
    End Function
    Dim Myip As String


    Dim Settaggi As New List(Of String)
    Function EstraiValoreCampo(ByRef s As String) As String
        Return (s.Substring(s.IndexOf("=") + 1))
    End Function

    Sub LoadClientSETT()
        Dim t As String

        Dim fileReader As System.IO.StreamReader = Nothing
        'carica settaggi
        Try
            fileReader = My.Computer.FileSystem.OpenTextFileReader(".server_settings")
        Catch ex As Exception
            MsgBox(ex.ToString)
            My.Computer.FileSystem.WriteAllText(".server_settings", "", True)
        End Try

        t = fileReader.ReadLine()

        Settaggi.Add(EstraiValoreCampo(t)) 'server ip, gg, freq

        fileReader.Close()


    End Sub

    Sub SaveClientSETT() ' al momento inutilizzata
        Dim FileWriter As System.IO.StreamWriter = Nothing

        If My.Computer.FileSystem.FileExists(".server_settings") Then
            My.Computer.FileSystem.DeleteFile(".server_settings")
        End If

        Try
            FileWriter = My.Computer.FileSystem.OpenTextFileWriter(".server_settings", True)
        Catch ex As Exception
            MsgBox(ex.ToString)
            Me.Close()
        End Try

        FileWriter.WriteLine("[server IP]=" & Settaggi(0))
        FileWriter.Close()
    End Sub


    Private Sub Fclient_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Me.Hide()
        LoadClientSETT()
        Dim IP As String = Settaggi(0)
        'Dim serverIp As Net.IPAddress = Net.IPAddress.Parse(IP)
        If IP = "" Then
            '            Msg("Errore: Ip vuoto")
            Me.Close()
        End If

        'start
        Try
            clientSocket.Connect(IP, 8888)
            '            Msg("Client Started")

        Catch ex As Exception
            MsgBox(ex.ToString)
            Close()
        End Try
        '   Me.TopMost = True
        uname = System.Windows.Forms.SystemInformation.UserName

        client = System.Windows.Forms.SystemInformation.ComputerName

        'login
        Myip = GetMyIP()
        serverStream = clientSocket.GetStream()
        Dim outStream As Byte() = System.Text.Encoding.ASCII.GetBytes(Now.ToShortDateString & ";" & TimeString & ";" & client & ";" & "I" & ";" & uname & ";" & Myip & "$")
        serverStream.Write(outStream, 0, outStream.Length)
        serverStream.Flush()
        Timer1.Enabled = True



    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim inStream(10) As Byte
        Dim buffSize As Integer = inStream.Length
        Dim returndata As String
        'Timer1.Enabled = False
        Try
            If Not serverStream.DataAvailable Then
                Exit Sub
            End If
            'ascolta comandi server
            serverStream.Read(inStream, 0, buffSize)
            returndata = System.Text.Encoding.ASCII.GetString(inStream)
            returndata = returndata.Substring(0, returndata.IndexOf("$"))
            Select Case returndata
                Case "off"
                    Process.Start("shutdown.exe", "/s /t 5") 'shutdown
                Case "dis"
                    Process.Start("shutdown.exe", "/l /f") 'disconnect subito

            End Select
            Timer1.Enabled = False
        Catch ex As Exception
            MsgBox(ex.ToString)
            Close()
        End Try
        Timer1.Enabled = True
    End Sub


    Private Sub TSchiudi_Click(sender As Object, e As EventArgs) Handles TSchiudi.Click
        Close()
    End Sub

    Sub ClientLogout()
        Dim outStream As Byte() = System.Text.Encoding.ASCII.GetBytes(Now.ToShortDateString & ";" & TimeString & ";" & client & ";" & "O" & ";" & uname & ";" & Myip & "$")
        'logout
        If clientSocket.Connected Then
            Try
                serverStream.Write(outStream, 0, outStream.Length)
                serverStream.Flush()

            Catch ex As Exception
                MsgBox(ex.ToString)

            End Try

        End If

    End Sub

    Private Sub FClient_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        ClientLogout()
    End Sub




End Class
