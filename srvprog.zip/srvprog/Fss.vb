﻿
Public Class Fss
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Timer1.Enabled = False

        Server.Show()
        Timer2.Enabled = True
    End Sub
    Dim Op As String = Me.Opacity
    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick

        Op -= 0.03
        If Op = 0 Then
            Timer2.Enabled = False
        Else
            Me.Opacity = Op
        End If
    End Sub
End Class