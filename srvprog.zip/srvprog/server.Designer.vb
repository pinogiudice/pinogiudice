﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Server
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla mediante l'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Server))
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Lblog = New System.Windows.Forms.ListBox()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TBrecTot = New System.Windows.Forms.TextBox()
        Me.TBrecEff = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GG = New System.Windows.Forms.NumericUpDown()
        Me.Frequenza = New System.Windows.Forms.NumericUpDown()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Bexport = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Bserver = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Lmsg = New System.Windows.Forms.Label()
        Me.Elenco = New System.Windows.Forms.DataGridView()
        Me.id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Data = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Ora = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LinOut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Client = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.UserName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ClientIP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Bdisconnetti = New System.Windows.Forms.Button()
        Me.Bspegni = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        CType(Me.GG, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Frequenza, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.Elenco, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Timer1
        '
        '
        'Lblog
        '
        Me.Lblog.FormattingEnabled = True
        Me.Lblog.Location = New System.Drawing.Point(3, 509)
        Me.Lblog.Name = "Lblog"
        Me.Lblog.Size = New System.Drawing.Size(1136, 121)
        Me.Lblog.TabIndex = 0
        '
        'Timer2
        '
        Me.Timer2.Interval = 1000
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(45, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "DB Rec"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 44)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(43, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Rec Eff"
        '
        'TBrecTot
        '
        Me.TBrecTot.BackColor = System.Drawing.SystemColors.Info
        Me.TBrecTot.Enabled = False
        Me.TBrecTot.Location = New System.Drawing.Point(61, 15)
        Me.TBrecTot.Name = "TBrecTot"
        Me.TBrecTot.ReadOnly = True
        Me.TBrecTot.Size = New System.Drawing.Size(100, 20)
        Me.TBrecTot.TabIndex = 5
        '
        'TBrecEff
        '
        Me.TBrecEff.BackColor = System.Drawing.SystemColors.Info
        Me.TBrecEff.Enabled = False
        Me.TBrecEff.Location = New System.Drawing.Point(61, 41)
        Me.TBrecEff.Name = "TBrecEff"
        Me.TBrecEff.ReadOnly = True
        Me.TBrecEff.Size = New System.Drawing.Size(100, 20)
        Me.TBrecEff.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(32, 74)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(23, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "GG"
        '
        'GG
        '
        Me.GG.Location = New System.Drawing.Point(61, 67)
        Me.GG.Name = "GG"
        Me.GG.ReadOnly = True
        Me.GG.Size = New System.Drawing.Size(65, 20)
        Me.GG.TabIndex = 8
        '
        'Frequenza
        '
        Me.Frequenza.Increment = New Decimal(New Integer() {500, 0, 0, 0})
        Me.Frequenza.Location = New System.Drawing.Point(61, 115)
        Me.Frequenza.Maximum = New Decimal(New Integer() {5000, 0, 0, 0})
        Me.Frequenza.Minimum = New Decimal(New Integer() {50, 0, 0, 0})
        Me.Frequenza.Name = "Frequenza"
        Me.Frequenza.ReadOnly = True
        Me.Frequenza.Size = New System.Drawing.Size(65, 20)
        Me.Frequenza.TabIndex = 11
        Me.Frequenza.Value = New Decimal(New Integer() {2000, 0, 0, 0})
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(13, 101)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 39)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Freq." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Refresh" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Elenco"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(132, 117)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(38, 13)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "millsec"
        '
        'Bexport
        '
        Me.Bexport.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bexport.Image = Global.srvprog.My.Resources.Resources._DatabaseExport
        Me.Bexport.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Bexport.Location = New System.Drawing.Point(12, 264)
        Me.Bexport.Name = "Bexport"
        Me.Bexport.Size = New System.Drawing.Size(165, 42)
        Me.Bexport.TabIndex = 15
        Me.Bexport.Text = "Export"
        Me.Bexport.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Bexport.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Image = Global.srvprog.My.Resources.Resources._NetworkOpen
        Me.Button2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button2.Location = New System.Drawing.Point(12, 212)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(165, 42)
        Me.Button2.TabIndex = 14
        Me.Button2.Text = "Listener Attivo"
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Bserver
        '
        Me.Bserver.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bserver.Image = Global.srvprog.My.Resources.Resources._NotepadOpen
        Me.Bserver.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Bserver.Location = New System.Drawing.Point(12, 157)
        Me.Bserver.Name = "Bserver"
        Me.Bserver.Size = New System.Drawing.Size(165, 45)
        Me.Bserver.TabIndex = 9
        Me.Bserver.Text = "Elenco ON"
        Me.Bserver.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Bserver.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Image = Global.srvprog.My.Resources.Resources.Person
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.Location = New System.Drawing.Point(12, 561)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(165, 44)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "About"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Lblog)
        Me.Panel1.Controls.Add(Me.Lmsg)
        Me.Panel1.Controls.Add(Me.Elenco)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel1.Location = New System.Drawing.Point(183, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1148, 658)
        Me.Panel1.TabIndex = 16
        '
        'Lmsg
        '
        Me.Lmsg.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lmsg.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Lmsg.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lmsg.Location = New System.Drawing.Point(0, 631)
        Me.Lmsg.Name = "Lmsg"
        Me.Lmsg.Size = New System.Drawing.Size(1148, 27)
        Me.Lmsg.TabIndex = 16
        '
        'Elenco
        '
        Me.Elenco.AllowUserToAddRows = False
        Me.Elenco.AllowUserToDeleteRows = False
        Me.Elenco.AllowUserToResizeRows = False
        Me.Elenco.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.Elenco.BackgroundColor = System.Drawing.SystemColors.Info
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.AppWorkspace
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Elenco.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.Elenco.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Elenco.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.id, Me.Data, Me.Ora, Me.LinOut, Me.Client, Me.UserName, Me.ClientIP})
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Info
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Elenco.DefaultCellStyle = DataGridViewCellStyle9
        Me.Elenco.EnableHeadersVisualStyles = False
        Me.Elenco.GridColor = System.Drawing.SystemColors.ControlText
        Me.Elenco.Location = New System.Drawing.Point(3, 3)
        Me.Elenco.Name = "Elenco"
        Me.Elenco.ReadOnly = True
        Me.Elenco.RowHeadersVisible = False
        Me.Elenco.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.Elenco.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Elenco.Size = New System.Drawing.Size(1136, 500)
        Me.Elenco.TabIndex = 2
        '
        'id
        '
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.id.DefaultCellStyle = DataGridViewCellStyle2
        Me.id.HeaderText = "Cli_id"
        Me.id.Name = "id"
        Me.id.ReadOnly = True
        Me.id.Width = 50
        '
        'Data
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Data.DefaultCellStyle = DataGridViewCellStyle3
        Me.Data.HeaderText = "Data"
        Me.Data.Name = "Data"
        Me.Data.ReadOnly = True
        Me.Data.Width = 120
        '
        'Ora
        '
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Ora.DefaultCellStyle = DataGridViewCellStyle4
        Me.Ora.HeaderText = "Ora"
        Me.Ora.Name = "Ora"
        Me.Ora.ReadOnly = True
        Me.Ora.Width = 80
        '
        'LinOut
        '
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.LinOut.DefaultCellStyle = DataGridViewCellStyle5
        Me.LinOut.HeaderText = "IN or Out"
        Me.LinOut.Name = "LinOut"
        Me.LinOut.ReadOnly = True
        '
        'Client
        '
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Client.DefaultCellStyle = DataGridViewCellStyle6
        Me.Client.HeaderText = "Computer"
        Me.Client.Name = "Client"
        Me.Client.ReadOnly = True
        Me.Client.Width = 300
        '
        'UserName
        '
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserName.DefaultCellStyle = DataGridViewCellStyle7
        Me.UserName.HeaderText = "Profilo"
        Me.UserName.Name = "UserName"
        Me.UserName.ReadOnly = True
        Me.UserName.Width = 300
        '
        'ClientIP
        '
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClientIP.DefaultCellStyle = DataGridViewCellStyle8
        Me.ClientIP.HeaderText = "Clientip"
        Me.ClientIP.Name = "ClientIP"
        Me.ClientIP.ReadOnly = True
        Me.ClientIP.Width = 170
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Image = Global.srvprog.My.Resources.Resources._ExitGrande
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button3.Location = New System.Drawing.Point(12, 509)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(165, 42)
        Me.Button3.TabIndex = 17
        Me.Button3.Text = "Uscita"
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Bdisconnetti
        '
        Me.Bdisconnetti.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bdisconnetti.Image = Global.srvprog.My.Resources.Resources._NetworkClose
        Me.Bdisconnetti.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Bdisconnetti.Location = New System.Drawing.Point(12, 323)
        Me.Bdisconnetti.Name = "Bdisconnetti"
        Me.Bdisconnetti.Size = New System.Drawing.Size(165, 42)
        Me.Bdisconnetti.TabIndex = 18
        Me.Bdisconnetti.Text = "Disconnetti Cli"
        Me.Bdisconnetti.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Bdisconnetti.UseVisualStyleBackColor = True
        '
        'Bspegni
        '
        Me.Bspegni.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bspegni.Image = Global.srvprog.My.Resources.Resources._NetworkDelete
        Me.Bspegni.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Bspegni.Location = New System.Drawing.Point(12, 380)
        Me.Bspegni.Name = "Bspegni"
        Me.Bspegni.Size = New System.Drawing.Size(165, 42)
        Me.Bspegni.TabIndex = 19
        Me.Bspegni.Text = "Spegni Cli"
        Me.Bspegni.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Bspegni.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Image = Global.srvprog.My.Resources.Resources._CopyCreate
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button4.Location = New System.Drawing.Point(12, 439)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(165, 42)
        Me.Button4.TabIndex = 20
        Me.Button4.Text = "Nuova Vers. Cli"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Server
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1331, 658)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Bspegni)
        Me.Controls.Add(Me.Bdisconnetti)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Bexport)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Frequenza)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Bserver)
        Me.Controls.Add(Me.GG)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TBrecEff)
        Me.Controls.Add(Me.TBrecTot)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Name = "Server"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ServerMthread (prof. giudice)"
        CType(Me.GG, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Frequenza, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        CType(Me.Elenco, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Lblog As ListBox
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TBrecTot As TextBox
    Friend WithEvents TBrecEff As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents GG As NumericUpDown
    Friend WithEvents Bserver As Button
    Friend WithEvents Frequenza As NumericUpDown
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Bexport As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Elenco As DataGridView
    Friend WithEvents Pmotivo As DataGridViewTextBoxColumn
    Friend WithEvents Lmsg As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents id As DataGridViewTextBoxColumn
    Friend WithEvents Data As DataGridViewTextBoxColumn
    Friend WithEvents Ora As DataGridViewTextBoxColumn
    Friend WithEvents LinOut As DataGridViewTextBoxColumn
    Friend WithEvents Client As DataGridViewTextBoxColumn
    Friend WithEvents UserName As DataGridViewTextBoxColumn
    Friend WithEvents ClientIP As DataGridViewTextBoxColumn
    Friend WithEvents Bdisconnetti As Button
    Friend WithEvents Bspegni As Button
    Friend WithEvents Button4 As Button
End Class
