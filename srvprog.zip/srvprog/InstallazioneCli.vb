﻿Public Class FinstallazioneCli
    Dim fn As String
    Private Sub Binst_Click(sender As Object, e As EventArgs) Handles Binst.Click
        Dim p, completeP As String
        Me.Cursor = Cursors.AppStarting
        For i As Integer = 0 To LBip.Items.Count - 1
            completeP = "\\" & LBip.Items(i).ToString & TBa.Text.Substring(TBa.Text.IndexOf("\")) & "\" & fn
            p = IO.Path.GetDirectoryName(completeP)
            If My.Computer.FileSystem.DirectoryExists(p) Then
                My.Computer.FileSystem.CopyFile(TBda.Text, completeP, True)
            End If

        Next
        Me.Cursor = Cursors.Default
        MsgBox("Installazione Nuova versione Client Effettuata", MsgBoxStyle.Information)
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        If OFDfile.ShowDialog = DialogResult.OK Then
            TBda.Text = OFDfile.FileName
            fn = IO.Path.GetFileName(OFDfile.FileName)
        End If
    End Sub

    Private Sub FinstallazioneCli_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim t As String
        Dim filereader As System.IO.StreamReader

        filereader = My.Computer.FileSystem.OpenTextFileReader("ips.txt")
        LBip.Items.Clear()


        t = filereader.ReadLine()

        While t <> Nothing
            LBip.Items.Add(t)
            t = filereader.ReadLine()
        End While

        filereader.Close()

    End Sub
End Class