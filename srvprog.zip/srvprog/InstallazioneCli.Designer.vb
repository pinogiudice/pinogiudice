﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FinstallazioneCli
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla mediante l'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.TBda = New System.Windows.Forms.TextBox()
        Me.TBa = New System.Windows.Forms.TextBox()
        Me.Binst = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.OFDfile = New System.Windows.Forms.OpenFileDialog()
        Me.LBip = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'TBda
        '
        Me.TBda.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TBda.Location = New System.Drawing.Point(54, 39)
        Me.TBda.Name = "TBda"
        Me.TBda.ReadOnly = True
        Me.TBda.Size = New System.Drawing.Size(948, 26)
        Me.TBda.TabIndex = 0
        '
        'TBa
        '
        Me.TBa.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TBa.Location = New System.Drawing.Point(54, 102)
        Me.TBa.Name = "TBa"
        Me.TBa.Size = New System.Drawing.Size(948, 26)
        Me.TBa.TabIndex = 1
        '
        'Binst
        '
        Me.Binst.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Binst.Location = New System.Drawing.Point(433, 170)
        Me.Binst.Name = "Binst"
        Me.Binst.Size = New System.Drawing.Size(75, 39)
        Me.Binst.TabIndex = 2
        Me.Binst.Text = "Installa"
        Me.Binst.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(7, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 24)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "File"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(28, 102)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(20, 24)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "a"
        '
        'OFDfile
        '
        Me.OFDfile.ShowReadOnly = True
        '
        'LBip
        '
        Me.LBip.FormattingEnabled = True
        Me.LBip.Location = New System.Drawing.Point(1023, 39)
        Me.LBip.Name = "LBip"
        Me.LBip.Size = New System.Drawing.Size(120, 186)
        Me.LBip.TabIndex = 10
        '
        'FinstallazioneCli
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1155, 371)
        Me.Controls.Add(Me.LBip)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Binst)
        Me.Controls.Add(Me.TBa)
        Me.Controls.Add(Me.TBda)
        Me.Name = "FinstallazioneCli"
        Me.Text = "InstallazioneCli"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TBda As TextBox
    Friend WithEvents TBa As TextBox
    Friend WithEvents Binst As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents OFDfile As OpenFileDialog
    Friend WithEvents LBip As ListBox
End Class
