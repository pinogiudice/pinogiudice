﻿Imports System.Net.Sockets
Imports System.Text
Imports srvprog

Public Class Server

    Structure Rec
        Dim id As Integer
        Dim Data As String
        Dim Ora As String
        Dim Cognome As String
        Dim Nome As String
        Dim ClientName As String
        Dim tipoIoO As Char
        Dim Uname As String
        Dim Ruolo As String
        Dim Motivo As String
        Dim ClientIP As String



        Sub New(id As Integer, Data As Date, Ora As DateTime, Cognome As String, Nome As String, ClientName As String, tipoIoO As Char, Uname As String, Ruolo As String, Motivo As String, ClientIP As String)
            Me.id = id
            Me.Data = Data
            Me.Ora = Ora
            Me.Cognome = Cognome
            Me.Nome = Nome
            Me.ClientName = ClientName
            Me.tipoIoO = tipoIoO
            Me.Uname = Uname
            Me.Ruolo = Ruolo
            Me.Motivo = Motivo
            Me.ClientIP = ClientIP
        End Sub

    End Structure

    Public Class DB
        ReadOnly NomeDB As String
        Dim NumRec As UInt32
        Friend Recs As New List(Of Rec)

        Sub New(DBPath As String)
            Me.NomeDB = DBPath

            ApreDB(Me.NomeDB)
        End Sub

        Sub ApreDB(ByVal NomeDB As String)
            'se non esiste lo crea
            Dim t As String
            If Not My.Computer.FileSystem.FileExists(NomeDB) Then

                My.Computer.FileSystem.WriteAllText(NomeDB, "0", True)
            Else
                'carica DB
                Dim fileReader As System.IO.StreamReader
                Dim r As String()
                fileReader = My.Computer.FileSystem.OpenTextFileReader(NomeDB)
                Dim i As Integer = 0
                Dim appRec As Rec
                t = fileReader.ReadLine() ' num rec
                NumRec = Val(t)
                t = fileReader.ReadLine()
                While t <> Nothing
                    r = Split(t, ";")

                    appRec.id = Val(r(0))
                    appRec.Data = r(1)
                    appRec.Ora = r(2)
                    appRec.Cognome = r(3)
                    appRec.Nome = r(4)
                    appRec.ClientName = r(5)
                    appRec.tipoIoO = r(6)
                    appRec.Uname = r(7)
                    appRec.Ruolo = r(8)
                    appRec.Motivo = r(9)
                    appRec.ClientIP = r(10)
                    Addrec(appRec)
                    t = fileReader.ReadLine()

                End While
                fileReader.Close()
            End If
        End Sub

        'scrive dati, legge , DBflush
        Sub Addrec(ByRef R As Rec)
            Recs.Add(R)
        End Sub

        Sub DBexport()
            Server.Timer1.Enabled = False
            Server.Timer2.Enabled = False

            Dim nf As String = CreaBck()

            My.Computer.FileSystem.DeleteFile(NomeDB)
            Server.Timer1.Enabled = True
            Server.Timer2.Enabled = True
            Server.Lblog.Items.Add("Db esportato su " & nf)
        End Sub

        Sub FlushTxt()
            Dim filewriter As System.IO.StreamWriter


            Dim nf As String = CreaBck()

            My.Computer.FileSystem.DeleteFile(NomeDB)


            filewriter = My.Computer.FileSystem.OpenTextFileWriter(NomeDB, True)


            Dim t As String
            filewriter.WriteLine(Recs.Count.ToString)

            For i As Integer = 0 To Recs.Count - 1
                t = Recs(i).id.ToString + ";"
                t += Recs(i).Data + ";"
                t += Recs(i).Ora + ";"
                t += Recs(i).Cognome + ";"
                t += Recs(i).Nome + ";"
                t += Recs(i).ClientName + ";"
                t += Recs(i).tipoIoO + ";"
                t += Recs(i).Uname + ";"
                t += Recs(i).Ruolo + ";"
                t += Recs(i).Motivo + ";"
                t += Recs(i).ClientIP

                filewriter.WriteLine(t)


            Next
            filewriter.Close()
        End Sub

        Sub Chiude()
            FlushTxt()
        End Sub

        Function CreaBck()

            Dim dirPath As String = Application.StartupPath + "\anno_" + Str(Year(Now))
            Dim nomefile As String = dirPath + "\" + Trim(Str(Now.Day)) + MonthName(Month(Now)) + Str(Year(Now)) + ".csv"


            ' crea cartella se non esiste
            If My.Computer.FileSystem.DirectoryExists(dirPath) = False Then
                My.Computer.FileSystem.CreateDirectory(dirPath)
            End If

            'elimina eventuale file bck esistente
            If My.Computer.FileSystem.FileExists(nomefile) Then
                My.Computer.FileSystem.DeleteFile(nomefile)
            End If

            My.Computer.FileSystem.CopyFile(NomeDB, nomefile)

            Return (nomefile)
        End Function


    End Class
    Dim serverIp As Net.IPAddress
    Shared DataBase As New DB("Database")
    Dim serverSocket As TcpListener
    Dim clientSocket As TcpClient
    Dim counter As Integer

    Public Property DataBase1 As DB
        Get
            Return DataBase
        End Get
        Set(value As DB)
            DataBase = value
        End Set
    End Property

    Dim Settaggi() As String
    Sub GetServerSETT()
        Try
            Dim app As String = My.Computer.FileSystem.ReadAllText(".server_settings")
            Settaggi = Split(app, ",")
        Catch

        End Try
    End Sub

    Sub SetServerSETT()
        Dim s As String = Settaggi(0) + "," + GG.Value.ToString + "," + Frequenza.Value.ToString
        Try
            My.Computer.FileSystem.WriteAllText(".server_settings", s, False)
        Catch

        End Try
    End Sub


    Private Sub StartServerSocket()

        Dim IP As String = Settaggi(0)

        If IP = "" Then
            Msg("Errore: Ip vuoto")
            Me.Close()
        End If

        serverIp = Net.IPAddress.Parse(IP)
        Try
            serverSocket = New TcpListener(serverIp, 8888)
            serverSocket.Start()
            Msg("Server Started")
            counter = 0
        Catch ex As Exception
            MsgBox(ex.ToString)
            Me.Close()
        End Try
        Bserver.Text = "Elenco ON"
        Button2.Text = "Listener ON"
        'inizializza counter per id_client
        If DataBase.Recs.Count > 0 Then
            counter = DataBase1.Recs(DataBase.Recs.Count - 1).id
        End If
    End Sub
    Private Sub Msg(ByVal mesg As String)
        mesg.Trim()
        Lblog.Items.Add(mesg)
    End Sub


    Dim NumEff As Integer
    Private Sub CaricaElenco()
        'sarebbe opportuno disabilitare timer1 ?
        Dim app As Integer
        'Timer1.Enabled = False
        Elenco.Rows.Clear()
        Dim d, temp As Date
        NumEff = 0
        GG.Value = Settaggi(1)
        TBrecTot.Text = DataBase1.Recs.Count
        For i As Integer = 0 To DataBase1.Recs.Count - 1
            Try

                With DataBase1.Recs(i)
                    'cerca .id: se non lo trova : addrow, altrimenti update
                    app = CercaID(.id)
                    If app < 0 Then
                        d = .Data
                        temp = DateAdd("d", -Val(Settaggi(1)), Now)
                        If d.ToString("dd/MM/yyyy") >= temp.ToString("dd/MM/yyyy") Then
                            Elenco.Rows.Add(.id, .Cognome, .Nome, .Data, .Ora, If(.tipoIoO = "I", "LogIn", If(.tipoIoO = "O", "LogOut", "Start")), .ClientName, .Uname, .Ruolo, .Motivo, .ClientIP)
                            NumEff += 1
                        End If
                    Else
                        Select Case .tipoIoO
                            Case "I"
                                'UpdateElenco() cognome,nome,client, uname, data e ora, tipo
                                Elenco(1, app).Value = .Cognome
                                Elenco(2, app).Value = .Nome
                                Elenco(3, app).Value = .Data
                                Elenco(4, app).Value = .Ora
                                Elenco(5, app).Value = "LogIn"
                                Elenco(6, app).Value = .ClientName
                                Elenco(7, app).Value = .Uname
                                Elenco(8, app).Value = .Ruolo
                                Elenco(9, app).Value = .Motivo
                                Elenco(10, app).Value = .ClientIP
                            Case "O"
                                'update data, ora, tipo
                                Elenco(3, app).Value = .Data
                                Elenco(4, app).Value = .Ora
                                Elenco(5, app).Value = "LogOut"
                        End Select
                    End If

                End With

            Catch

            End Try
        Next
        TBrecEff.Text = NumEff
        If NumEff > 0 Then

            Elenco.ClearSelection()
            Elenco.FirstDisplayedScrollingRowIndex = Elenco.RowCount - 1
            Elenco.Rows(Elenco.RowCount - 1).Selected = True

        End If
        'Timer1.Enabled = True

    End Sub

    Private Function CercaID(id As Integer) As Integer
        Dim res As Integer = -1
        For i As Integer = 0 To Elenco.RowCount - 1
            If Elenco(0, i).Value = id Then
                res = i
                Exit For
            End If
        Next
        Return (res)
    End Function


    Private Sub Server_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ' System.Diagnostics.Process.Start("shutdown", "-s -f -m \\PORTATILE -t 00")

        GetServerSETT()
        Timer2.Interval = Val(Settaggi(2))
        Frequenza.Value = Val(Settaggi(2))
        StartServerSocket()
        Timer1.Enabled = True 'ascolto tcplistner
        Timer2.Enabled = True 'carica elenco
        HandClient.Visible = False


    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim R As Rec

        If serverSocket.Pending Then
            Timer1.Enabled = False
            counter += 1
            clientSocket = serverSocket.AcceptTcpClient()
            Msg("Client Nr.:" + Convert.ToString(counter) + " started!")

            Dim client As New HandClient
            client.StartClient(clientSocket, Convert.ToString(counter))

            R.id = counter
            R.Data = Now.ToShortDateString
            R.Ora = TimeString
            R.Cognome = ""
            R.Nome = ""
            R.ClientName = "Client n. " & counter.ToString
            R.tipoIoO = "S"
            R.Uname = ""
            R.Ruolo = ""
            R.Motivo = ""
            R.ClientIP = ""
            DataBase1.Addrec(R)
            Timer1.Enabled = True
        End If
    End Sub

    Private Sub Server_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        SetServerSETT()
        DataBase1.Chiude()
        Try
            clientSocket.Close()
            serverSocket.Stop()
        Catch
        End Try

    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        ' Timer1.Enabled = False
        CaricaElenco()
        'Timer1.Enabled = True
    End Sub

    Private Sub Elenco_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles Elenco.CellFormatting
        Try

            If e.ColumnIndex = 5 Then
                Select Case e.Value.ToString.ToUpper
                    Case "LOGIN"
                        e.CellStyle.ForeColor = Color.Green
                    Case "LOGOUT"
                        e.CellStyle.ForeColor = Color.Red

                End Select
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Fabout.Show()
    End Sub

    Private Sub GG_ValueChanged(sender As Object, e As EventArgs) Handles GG.ValueChanged
        Settaggi(1) = GG.Value
    End Sub

    Private Sub Bserver_Click(sender As Object, e As EventArgs) Handles Bserver.Click
        If Timer2.Enabled = True Then
            Bserver.Text = "Elenco OFF"
            Bserver.Image = My.Resources.Notepad_Close
            Timer2.Enabled = False
        Else
            Bserver.Text = "Elenco ON"
            Bserver.Image = My.Resources.Notepad_Open
            Timer2.Enabled = True
        End If

    End Sub

    Private Sub Frequenza_ValueChanged(sender As Object, e As EventArgs) Handles Frequenza.ValueChanged
        Timer2.Enabled = False
        Timer2.Interval = Frequenza.Value
        Timer2.Enabled = True

    End Sub

    Sub CercaIds(id As Integer)
        Dim cont As Integer = 3

        Dettaglio.Rows.Clear()
        For i As Integer = 0 To DataBase1.Recs.Count - 1
            If DataBase1.Recs(i).id = id Then
                With DataBase1.Recs(i)
                    Dettaglio.Rows.Add(.id, .Cognome, .Nome, .Data, .Ora, If(.tipoIoO = "I", "LogIn", If(.tipoIoO = "O", "LogOut", "Start")), .ClientName, .Uname, .Ruolo, .Motivo)
                End With

                cont -= 1
            End If
            If cont = 0 Then Exit For
        Next
    End Sub

    Private Sub Elenco_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles Elenco.CellClick

        If Not Timer2.Enabled Then
            Dim temp As Integer
            temp = Elenco.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, True).Y + Elenco.Top + sender.rows(e.RowIndex).height
            Dettaglio.Top = temp
            Dettaglio.Visible = True
            CercaIds(Elenco(0, e.RowIndex).Value)
            Dettaglio.ClearSelection()
        End If

    End Sub



    Private Sub Server_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            Dettaglio.Visible = False

        End If

    End Sub

    Private Sub Dettaglio_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles Dettaglio.CellFormatting
        Try

            If e.ColumnIndex = 5 Then
                Select Case e.Value.ToString.ToUpper
                    Case "LOGIN"
                        e.CellStyle.ForeColor = Color.Green
                    Case "LOGOUT"
                        e.CellStyle.ForeColor = Color.Red

                End Select
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If Timer1.Enabled = True Then
            'Button2.BackColor = Color.Red
            Button2.Text = "Listener OFF"
            Button2.Image = My.Resources.Network_Close
            Timer1.Enabled = False
        Else
            Button2.Text = "Listener ON"
            'Button2.BackColor = Color.Green
            Button2.Image = My.Resources.Network_Open
            Timer1.Enabled = True
        End If
    End Sub

    Private Sub Bexport_Click(sender As Object, e As EventArgs) Handles Bexport.Click
        DataBase1.DBexport()
    End Sub
End Class
