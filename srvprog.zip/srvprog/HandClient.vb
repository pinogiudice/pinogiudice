﻿Imports System.Net.Sockets
Imports System.Text

Public Class HandClient


    Dim requestCount As Integer
    Dim bytesFrom(1024) As Byte
    Dim dataFromClient As String
    'Dim sendBytes As [Byte]()
    'Dim serverResponse As String
    'Dim rCount As String

    Dim clientSocket As TcpClient
    Dim clNo As String
    Dim ctThread As Threading.Thread = New Threading.Thread(AddressOf DoChat)

    Public Sub StartClient(ByVal inClientSocket As TcpClient, ByVal clineNo As String)
        Me.clientSocket = inClientSocket
        Me.clNo = clineNo
        ctThread.Start()

    End Sub
    Private Delegate Sub DoChatDelegate()

    Private Function StringToRec(s As String) As Server.Rec
        Dim R As New Server.Rec
        Dim app As String()
        app = Split(s, ";")
        R.id = Me.clNo
        R.Data = CDate(app(0))
        R.Ora = CDate(app(1))
        R.ClientName = app(2)
        R.tipoIoO = app(3)
        R.Uname = app(4)
        R.ClientIP = app(5)
        Return (R)

    End Function

    Private Sub DoChat()
        Dim R As Server.Rec
        If Me.InvokeRequired Then
            Me.Invoke(New DoChatDelegate(AddressOf DoChat))
        Else
            requestCount = 0
            '            While (requestCount < 2) 'login e logout
            While (True) 'login e logout
                Try
                        requestCount = requestCount + 1
                        Dim networkStream As NetworkStream = Me.clientSocket.GetStream()

                        networkStream.Read(bytesFrom, 0, bytesFrom.Length)

                        dataFromClient = System.Text.Encoding.ASCII.GetString(bytesFrom)
                        dataFromClient = dataFromClient.Substring(0, dataFromClient.IndexOf("$"))

                        R = StringToRec(dataFromClient)
                        R.SocketCli = Me.clientSocket
                        Server.DataBase1.Addrec(R)


                    Catch ex As Exception
                        '                   MsgBox(ex.ToString)
                        'Me.clientSocket.Close()
                        ctThread.Abort()
                    Close()
                End Try
            End While


        End If
    End Sub


End Class
