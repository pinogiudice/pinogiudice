﻿' 16 aprile 2022: cambio data e ora in date e datatime, tolgo motivo
' 23 aprile 2022: corretto bug click su intestazione
' 24 aprile 2022: aggiunto effetto dissolvenza spalshscreen
Imports System.Net.Sockets
Imports System.Text
Imports srvprog

Public Class Server

    Structure Rec
        Dim id As Integer
        Dim Data As Date
        Dim Ora As DateTime
        'Dim Cognome As String
        'Dim Nome As String
        Dim ClientName As String
        Dim tipoIoO As Char
        Dim Uname As String
        'Dim Ruolo As String
        Dim ClientIP As String
        Dim SocketCli As TcpClient


        Sub New(id As Integer, Data As Date, Ora As DateTime, ClientName As String, tipoIoO As Char, Uname As String, ClientIP As String)
            Me.id = id
            Me.Data = Data
            Me.Ora = Ora
            Me.ClientName = ClientName
            Me.tipoIoO = tipoIoO
            Me.Uname = Uname
            Me.ClientIP = ClientIP
        End Sub

    End Structure

    Public Class DB
        ReadOnly NomeDB As String
        Dim NumRec As UInt32
        Friend Recs As New List(Of Rec)

        Sub New(DBPath As String)
            Me.NomeDB = DBPath

            ApreDB(Me.NomeDB)
        End Sub

        Sub ApreDB(ByVal NomeDB As String)
            'se non esiste lo crea
            Dim t As String
            If Not My.Computer.FileSystem.FileExists(NomeDB) Then

                My.Computer.FileSystem.WriteAllText(NomeDB, "0", True)
            Else
                'carica DB
                Dim fileReader As System.IO.StreamReader
                Dim r As String()
                fileReader = My.Computer.FileSystem.OpenTextFileReader(NomeDB)
                Dim i As Integer = 0
                Dim appRec As Rec = Nothing
                t = fileReader.ReadLine() ' num rec
                NumRec = Val(t)
                t = fileReader.ReadLine()
                While t <> Nothing
                    r = Split(t, ";")

                    appRec.id = Val(r(0))

                    appRec.Data = CDate(r(1)).ToShortDateString
                    appRec.Ora = CDate(r(2))

                    appRec.ClientName = r(3)
                    appRec.tipoIoO = r(4)
                    appRec.Uname = r(5)
                    appRec.ClientIP = r(6)
                    Addrec(appRec)
                    t = fileReader.ReadLine()

                End While
                fileReader.Close()
            End If
            '            Sort() non serve, file già ordinato per data
        End Sub

        Sub Sort()
            Recs.Sort(Function(x As Rec, y As Rec)
                          Return x.Data.CompareTo(y.Data)
                      End Function)
        End Sub



        'scrive dati, legge , DBflush - potrebbe cancellare tabclient in caso logout
        Sub Addrec(ByRef R As Rec)
            ' If R.tipoIoO = "O" Then
            'Server.CercaClient(R.ClientIP, 1)
            'End If
            Recs.Add(R)
        End Sub

        Sub DBexport()
            Server.Timer1.Enabled = False
            Server.Timer2.Enabled = False

            Dim nf As String = CreaBck()

            '  My.Computer.FileSystem.DeleteFile(NomeDB)
            Server.Timer1.Enabled = True
            Server.Timer2.Enabled = True
            Server.Lmsg.Text = "Db esportato su " & nf
        End Sub


        Sub FlushTxt()
            Dim filewriter As System.IO.StreamWriter


            Dim nf As String = CreaBck()
            My.Computer.FileSystem.DeleteFile(NomeDB)


            filewriter = My.Computer.FileSystem.OpenTextFileWriter(NomeDB, True)


            Dim t As String
            filewriter.WriteLine(Recs.Count.ToString)

            For i As Integer = 0 To Recs.Count - 1
                t = Recs(i).id.ToString + ";"

                t += Recs(i).Data.ToShortDateString + ";"
                t += Recs(i).Ora.ToShortTimeString + ";"
                t += Recs(i).ClientName + ";"
                t += Recs(i).tipoIoO + ";"
                t += Recs(i).Uname + ";"
                t += Recs(i).ClientIP

                filewriter.WriteLine(t)


            Next
            filewriter.Close()
        End Sub

        Sub Chiude()
            FlushTxt()
        End Sub

        Function CreaBck()

            Dim dirPath As String = Application.StartupPath + "\anno_" + Str(Year(Now))
            Dim nomefile As String = dirPath + "\" + Trim(Str(Now.Day)) + MonthName(Month(Now)) + Str(Year(Now)) + ".csv"


            ' crea cartella se non esiste
            If My.Computer.FileSystem.DirectoryExists(dirPath) = False Then
                My.Computer.FileSystem.CreateDirectory(dirPath)
            End If

            'elimina eventuale file bck esistente
            If My.Computer.FileSystem.FileExists(nomefile) Then
                My.Computer.FileSystem.DeleteFile(nomefile)
            End If

            My.Computer.FileSystem.CopyFile(NomeDB, nomefile)

            Return (nomefile)
        End Function


    End Class
    Dim serverIp As Net.IPAddress
    Shared DataBase As New DB("Database")
    Dim serverSocket As TcpListener
    Dim portNum As Integer

    Dim counter As Integer

    Public Property DataBase1 As DB
        Get
            Return DataBase
        End Get
        Set(value As DB)
            DataBase = value
        End Set
    End Property


    Dim Settaggi As New List(Of String)

    Sub GetServerSETT()
        Dim t As String
        Dim fileReader As System.IO.StreamReader = Nothing
        'carica settaggi
        Try
            fileReader = My.Computer.FileSystem.OpenTextFileReader(".server_settings")
        Catch ex As Exception
            MsgBox(ex.ToString)
            Me.Close()
        End Try

        t = fileReader.ReadLine()
        While t <> Nothing
            Settaggi.Add(EstraiValoreCampo(t)) 'server ip, gg, freq
            t = fileReader.ReadLine()
        End While
        fileReader.Close()

    End Sub

    Function EstraiValoreCampo(ByRef s As String) As String
        Return (s.Substring(s.IndexOf("=") + 1))
    End Function




    Sub SetServerSETT()
        Dim FileWriter As System.IO.StreamWriter = Nothing

        If My.Computer.FileSystem.FileExists(".server_settings") Then
            My.Computer.FileSystem.DeleteFile(".server_settings")
        End If

        Try
            FileWriter = My.Computer.FileSystem.OpenTextFileWriter(".server_settings", True)
        Catch ex As Exception
            MsgBox(ex.ToString)
            Me.Close()
        End Try

        FileWriter.WriteLine("[server IP]=" & Settaggi(0))
        FileWriter.WriteLine("[visualizza login vecchi di gg]=" & GG.Value.ToString)
        FileWriter.WriteLine("[frequenza aggiornamento elenco login]=" & Frequenza.Value.ToString)
        FileWriter.Close()
    End Sub

    Function GetMyIP() As String
        Dim AllNetInterfaces = System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces()
        For Each NetworkInterface In AllNetInterfaces
            Dim props = NetworkInterface.GetIPProperties
            For Each address In props.UnicastAddresses
                If address.Address.AddressFamily = Net.Sockets.AddressFamily.InterNetwork Then
                    If NetworkInterface.OperationalStatus = System.Net.NetworkInformation.OperationalStatus.Up Then


                        Return (address.Address.ToString)
                    End If
                End If
            Next
        Next
        Return ""
    End Function


    Private Sub StartServerSocket()
        portNum = 8888
        Dim IP As String = Settaggi(0)
        'Dim IP As String = GetMyIP()

        If IP = "" Then
            Msg("Errore: Ip vuoto")
            Me.Close()
        End If

        serverIp = Net.IPAddress.Parse(IP)
        Try
            serverSocket = New TcpListener(serverIp, portNum)
            serverSocket.Start()
            Msg("Server Started")
            counter = 0
        Catch ex As Exception
            MsgBox(ex.ToString)
            Me.Close()
        End Try
        Bserver.Text = "Elenco ON"
        Button2.Text = "Listener ON"
        'inizializza counter per id_client
        If DataBase.Recs.Count > 0 Then
            counter = DataBase1.Recs(DataBase.Recs.Count - 1).id
        End If
    End Sub
    Private Sub Msg(ByVal mesg As String)
        mesg.Trim()
        Lblog.Items.Add(mesg)
    End Sub


    Dim NumEff As Integer
    Private Sub CaricaElenco()
        'sarebbe opportuno disabilitare timer1 ?
        Dim sel, app As Integer
        'Timer1.Enabled = False
        Elenco.Rows.Clear()
        Dim d, temp As Date
        NumEff = 0
        GG.Value = Settaggi(1)
        TBrecTot.Text = DataBase1.Recs.Count
        For i As Integer = 0 To DataBase1.Recs.Count - 1
            Try

                With DataBase1.Recs(i)
                    'cerca .id: se non lo trova : addrow, altrimenti update
                    app = CercaID(.id)
                    If app < 0 Then
                        d = .Data.ToShortDateString
                        temp = DateAdd("d", -Val(Settaggi(1)), Now)
                        '                        If d.ToString("dd/MM/yyyy") >= temp.ToString("dd/MM/yyyy") Then
                        If d.ToString("yyyy/MM/dd") >= temp.ToString("yyyy/MM/dd") Then
                            Elenco.Rows.Add(.id, .Data.ToShortDateString, .Ora.ToShortTimeString, If(.tipoIoO = "I", "LogIn", If(.tipoIoO = "O", "LogOut", "Start")), .ClientName, .Uname, .ClientIP)
                            NumEff += 1
                        End If
                    Else
                        Select Case .tipoIoO
                            Case "I"
                                'UpdateElenco() cognome,nome,client, uname, data e ora, tipo
                                Elenco("Data", app).Value = .Data.ToShortDateString
                                Elenco("Ora", app).Value = .Ora.ToShortTimeString
                                Elenco("LinOut", app).Value = "LogIn"
                                Elenco("Client", app).Value = .ClientName
                                Elenco("UserName", app).Value = .Uname
                                Elenco("ClientIP", app).Value = .ClientIP
                            Case "O"
                                'update data, ora, tipo
                                Elenco("Data", app).Value = .Data.ToShortDateString
                                Elenco("Ora", app).Value = .Ora.ToShortTimeString
                                Elenco("LinOut", app).Value = "LogOut"
                        End Select
                        'indice ultima riga aggiornata
                        sel = app
                    End If

                End With

            Catch

            End Try
        Next
        TBrecEff.Text = NumEff
        If NumEff > 0 Then

            Elenco.ClearSelection()
            Elenco.FirstDisplayedScrollingRowIndex = Elenco.RowCount - 1
            Elenco.Rows(sel).DefaultCellStyle.BackColor = Color.Gainsboro


            'Elenco.Rows(Elenco.RowCount - 1).Selected = True

        End If
        'Timer1.Enabled = True

    End Sub

    Private Function CercaID(id As Integer) As Integer
        Dim res As Integer = -1
        For i As Integer = 0 To Elenco.RowCount - 1
            If Elenco("id", i).Value = id Then
                res = i
                Exit For
            End If
        Next
        Return (res)
    End Function


    Private Sub Server_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' System.Diagnostics.Process.Start("shutdown", "-s -f -m \\PORTATILE -t 00")
        Me.Cursor = Cursors.AppStarting
        GetServerSETT()
        Timer2.Interval = Val(Settaggi(2))
        Frequenza.Value = Val(Settaggi(2))
        StartServerSocket()
        Timer1.Enabled = True 'ascolto tcplistner
        Timer2.Enabled = True 'carica elenco
        HandClient.Visible = False
        Lmsg.Text = "Server Multithread"
        Elenco.ClearSelection()

        ' Dim myNotifyIcon As New NotifyIcon
        ' Oggetto icona
        'myNotifyIcon.Icon = My.Resources.server
        ' indica la visibilità dell’icona
        'myNotifyIcon.Visible = True

        ' Testo che compare al passaggio del Mouse
        'myNotifyIcon.Text = "Notify Icon"

    End Sub

    Private Function CercaClient(ByVal id As Integer) As TcpClient
        'Dim ipend As Net.IPEndPoint  'clientSocket.Client.RemoteEndPoint

        For i As Integer = 0 To DataBase1.Recs.Count - 1
            If DataBase1.Recs(i).id = id Then
                Return DataBase1.Recs(i).SocketCli
            End If

        Next
        Return Nothing
    End Function


    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim R As Rec
        Dim clientSocket As TcpClient

        'ascolta richieste di connessione da parte dei client
        If serverSocket.Pending Then
            Timer1.Enabled = False
            counter += 1

            clientSocket = serverSocket.AcceptTcpClient()

            'TabClientSocket.Add(clientSocket)

            ' ip del client e hostclient name
            Dim ipend As Net.IPEndPoint = clientSocket.Client.RemoteEndPoint
            Dim Hname As Net.IPHostEntry = Net.Dns.GetHostEntry(ipend.Address.ToString)


            Msg("Cli.Nr.:" + Convert.ToString(counter) + " Hname : " + Hname.HostName + " started!")

            Dim client As New HandClient
            client.StartClient(clientSocket, Convert.ToString(counter))

            R.id = counter
            R.Data = Now.ToShortDateString
            R.Ora = TimeString
            R.ClientName = Hname.HostName.ToUpper
            R.tipoIoO = "S"
            R.Uname = ""
            R.ClientIP = ipend.Address.ToString
            R.SocketCli = clientSocket
            DataBase1.Addrec(R)
            Timer1.Enabled = True
        End If
    End Sub


    Private Sub Server_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        SetServerSETT()
        DataBase1.Chiude()
        Try
            '     For Each cs As TcpClient In TabClientSocket
            '    cs.Close()
            '   Next

            serverSocket.Stop()
        Catch
        End Try

    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        ' Timer1.Enabled = False
        CaricaElenco()
        Fss.Close()
        Me.Cursor = Cursors.Default
        'Timer1.Enabled = True
    End Sub





    Private Sub Elenco_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles Elenco.CellFormatting
        Try


            '            If e.ColumnIndex = 5 Then
            If e.ColumnIndex = Elenco.Rows(e.RowIndex).Cells("LinOut").ColumnIndex Then
                Select Case e.Value.ToString.ToUpper
                    Case "LOGIN"
                        e.CellStyle.ForeColor = Color.Green
                    Case "LOGOUT"
                        e.CellStyle.ForeColor = Color.Red

                End Select
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Fabout.Show()
    End Sub

    Private Sub GG_ValueChanged(sender As Object, e As EventArgs) Handles GG.ValueChanged
        Settaggi(1) = GG.Value
    End Sub

    Private Sub Bserver_Click(sender As Object, e As EventArgs) Handles Bserver.Click
        If Timer2.Enabled = True Then
            Bserver.Text = "Elenco OFF"
            Bserver.Image = My.Resources._NotepadClose
            Timer2.Enabled = False
        Else
            Bserver.Text = "Elenco ON"
            Bserver.Image = My.Resources._NotepadOpen
            Timer2.Enabled = True
        End If

    End Sub

    Private Sub Frequenza_ValueChanged(sender As Object, e As EventArgs) Handles Frequenza.ValueChanged
        Timer2.Enabled = False
        Timer2.Interval = Frequenza.Value
        Timer2.Enabled = True

    End Sub

    'Sub CercaIds(id As Integer)
    'Dim cont As Integer = 3

    '   Dettaglio.Rows.Clear()
    'For i As Integer = 0 To DataBase1.Recs.Count - 1
    'If DataBase1.Recs(i).id = id Then
    'With DataBase1.Recs(i)
    '               Dettaglio.Rows.Add(.id, .Data.ToShortDateString, .Ora.ToShortTimeString, If(.tipoIoO = "I", "LogIn", If(.tipoIoO = "O", "LogOut", "Start")), .ClientName, .Uname)
    '              TClientIP.Text = .ClientIP
    'End With
    '
    '       cont -= 1
    'End If
    'If cont = 0 Then Exit For
    'Next

    'End Sub




    'Private Sub Server_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
    'If e.KeyCode = Keys.Escape Then
    '       Dettaglio.Visible = False

    'End If

    'End Sub

    'Private Sub Dettaglio_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs)
    'Try

    'If e.ColumnIndex = Dettaglio.Rows(e.RowIndex).Cells("DLinOut").ColumnIndex Then
    'Select Case e.Value.ToString.ToUpper
    'Case "LOGIN"
    '                   e.CellStyle.ForeColor = Color.Green
    'Case "LOGOUT"
    '                   e.CellStyle.ForeColor = Color.Red

    'End Select
    'End If
    'Catch ex As Exception

    'End Try

    'End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If Timer1.Enabled = True Then
            'Button2.BackColor = Color.Red
            Button2.Text = "Listener OFF"
            Button2.Image = My.Resources._NetworkClose
            Timer1.Enabled = False
        Else
            Button2.Text = "Listener ON"
            'Button2.BackColor = Color.Green
            Button2.Image = My.Resources._NetworkOpen
            Timer1.Enabled = True
        End If
    End Sub

    Private Sub Bexport_Click(sender As Object, e As EventArgs) Handles Bexport.Click
        DataBase1.DBexport()
    End Sub

    ' Private Sub Elenco_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles Elenco.CellClick
    'If e.RowIndex >= 0 And e.RowIndex < Elenco.RowCount Then
    'If Not Timer2.Enabled Then
    ' Dim temp As Integer
    'temp = Elenco.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, True).Y + Elenco.Top + sender.rows(e.RowIndex).height
    'Dettaglio.Top = temp
    'Dettaglio.Visible = True
    '        CercaIds(Elenco("id", e.RowIndex).Value)
    '       Dettaglio.ClearSelection()

    'End If
    'End If

    'End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()

    End Sub


    Private Sub Bdisconnetti_Click(sender As Object, e As EventArgs) Handles Bdisconnetti.Click
        If Not Timer2.Enabled Then
            Dim r As TcpClient
            Dim elencoId As Integer

            Dim sendBytes As [Byte]()
            Dim serverCmd As String

            For i As Integer = 0 To Elenco.RowCount - 1
                If Elenco.Rows(i).Cells("LinOut").Value.ToString.ToUpper = "LOGIN" And Elenco.Rows(i).Selected Then
                    elencoId = Elenco.Rows(i).Cells("id").Value
                    r = CercaClient(elencoId)
                    'controllare r not nothing
                    If r IsNot Nothing Then
                        'invio comando di disconnessione al client 

                        serverCmd = "dis" & "$"

                        sendBytes = Encoding.ASCII.GetBytes(serverCmd)
                        r.GetStream().Write(sendBytes, 0, sendBytes.Length)

                        r.GetStream().Flush()
                        'r.GetStream().Close()
                    End If
                End If
            Next


        End If

    End Sub

    Private Sub Bspegni_Click(sender As Object, e As EventArgs) Handles Bspegni.Click
        If Not Timer2.Enabled Then
            Dim r As TcpClient
            Dim elencoId As Integer

            Dim sendBytes As [Byte]()
            Dim serverCmd As String

            For i As Integer = 0 To Elenco.RowCount - 1
                If Elenco.Rows(i).Selected Then
                    elencoId = Elenco.Rows(i).Cells("id").Value
                    r = CercaClient(elencoId)
                    'controllare r not nothing
                    If r IsNot Nothing Then
                        'invio comando di disconnessione al client 

                        serverCmd = "off" & "$"

                        sendBytes = Encoding.ASCII.GetBytes(serverCmd)
                        r.GetStream().Write(sendBytes, 0, sendBytes.Length)

                        r.GetStream().Flush()
                        'r.GetStream().Close()
                    End If
                End If
            Next


        End If

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        FinstallazioneCli.Show()
    End Sub

    '  Private Sub Elenco_CellMouseDown(sender As Object, e As DataGridViewCellMouseEventArgs) Handles Elenco.CellMouseDown
    ' Dim temp As Integer
    '    temp = DGMov.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, True).Y + DGMov.Top + sender.rows(e.RowIndex).height
    'Select Case sender.columns(e.ColumnIndex).DataPropertyName
    'Case "CodCat"

    '           ListBox3.Left = DGMov.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, True).X + DGMov.Left
    'If temp + ListBox3.Height > DGMov.Top + DGMov.Height Then
    '               ListBox3.Top = DGMov.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, True).Y + DGMov.Top - ListBox3.Height
    'Else
    '               ListBox3.Top = temp
    'End If

    '           cx = e.RowIndex
    '          cy = e.ColumnIndex
    '         ListBox3.Visible = True

    '    End Select
    '   End Sub
End Class
